# -*- coding: utf-8 -*-
"""
Created on Tue May 12 00:00:00 2020

@author: Shaji
"""

class ExecutionError(Exception):
    """
    User Defined Exception
    Please check the logs
    """
    pass