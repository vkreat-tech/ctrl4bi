
class ExecutionError(Exception):
    """
    User Defined Exception
    Please check the logs
    """
    pass