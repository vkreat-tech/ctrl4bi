# ctrl4bi.cleanser

##    scrub_pii(string)
        Usage: [arg1]:[String with PII]
        Description: Removes PII content from string. Be careful while performing this as this would remove even anything that looks like PII
        Returns: [String without PII]


# ctrl4bi.etl_testing		

##    column_level_check(source_df, target_df, primary_keys)
        Usage: [arg1]:[Pandas DataFrame - source], [arg2]:[Pandas DataFrame - target], [arg3]:[Primary keys (separated by comma)]
        Description: Performs column level testing between two DataFrames.
        Returns: [Mismatch Count], [Test Log (list)], [Pandas dataframe - mismatch (if any)]